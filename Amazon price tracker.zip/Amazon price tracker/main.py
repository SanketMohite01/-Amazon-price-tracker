import os
import smtplib
import requests
from bs4 import BeautifulSoup
from dotenv import load_dotenv


load_dotenv()
SMTP_ADDRESS = os.getenv("SMTP_ADDRESS")
EMAIL_ADDRESS = os.getenv("EMAIL_ADDRESS")
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD")


URL = "https://appbrewery.github.io/instant_pot/"
TARGET_PRICE = 100.00


response = requests.get(URL)
soup = BeautifulSoup(response.content, "html.parser")


price_text = soup.find(name="span", class_="a-offscreen").get_text()  
price = float(price_text.split("$")[1]) 

title_tag = soup.find(name="span", id="productTitle")
product_title = title_tag.get_text().strip() if title_tag else "Instant Pot"


if price < TARGET_PRICE:
    subject = "Price Alert!"
    body = f"{product_title} is now ${price}!\nBuy here: {URL}"
    message = f"Subject: {subject}\nContent-Type: text/plain; charset=utf-8\n\n{body}"

    with smtplib.SMTP(SMTP_ADDRESS, port=587) as connection:
        connection.starttls()
        connection.login(user=EMAIL_ADDRESS, password=EMAIL_PASSWORD)
        connection.sendmail(
            from_addr=EMAIL_ADDRESS,
            to_addrs=EMAIL_ADDRESS,
            msg=message.encode("utf-8")  
        )
    print("✅ Email sent successfully!")
else:
    print(f"ℹ️ No email sent. Current price: ${price}, Target price: ${TARGET_PRICE}")
